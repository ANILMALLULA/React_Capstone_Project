import React from "react";
import { MemoryRouter } from "react-router-dom";
import { Provider } from "react-redux";
import { cleanup, render } from "@testing-library/react";
import { shallow } from "enzyme";

import NavBar from "./NavBar";
import store from "../../store";

afterEach(cleanup);
describe("<NavBar />", () => {
  const wrapper = (
    <MemoryRouter>
      <Provider store={store}>
        <NavBar />
      </Provider>
    </MemoryRouter>
  );

  it("Navbar component should render without any Errors", () => {
    shallow(wrapper);
  });

  it("should render default Navs", () => {
    const { getByText } = render(wrapper);
    expect(getByText("Capstone Project")).toBeInTheDocument();
    expect(getByText("Home")).toBeInTheDocument();
    expect(getByText("View List")).toBeInTheDocument();
    expect(getByText("Add Product")).toBeInTheDocument();
    expect(getByText("Login")).toBeInTheDocument();
    expect(getByText("Charts")).toBeInTheDocument();
  });
});
