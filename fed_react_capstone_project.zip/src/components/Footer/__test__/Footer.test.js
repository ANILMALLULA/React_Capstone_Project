import React from "react";
import { shallow } from "enzyme";
import Footer from "../Footer";

import { findBytestAttr } from "../../../../Utils";

const setUp = (props = {}) => {
  const component = shallow(<Footer {...props} />);
  return component;
};

describe("Footer Component", () => {
  let component;
  beforeEach(() => {
    component = setUp();
  });
  it("renders without crashing", () => {
    const wrapper = findBytestAttr(component, "footer");
    expect(wrapper.length).toBe(1);
  });
  it("renders with address details", () => {
    const wrapper = findBytestAttr(component, "address");
    expect(wrapper.length).toBe(1);
  });
  it("renders with contact details", () => {
    const wrapper = findBytestAttr(component, "contact");
    expect(wrapper.length).toBe(1);
  });
});
