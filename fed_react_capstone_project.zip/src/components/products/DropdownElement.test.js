import React from "react";
import { MemoryRouter } from "react-router-dom";
import { Provider } from "react-redux";
import { cleanup, render } from "@testing-library/react";
import { shallow } from "enzyme";
import store from "../../store";
import DropdownElement from "./DropdownElement";

afterEach(cleanup);
describe("<DropdownElement />", () => {
  const wrapper = (
    <MemoryRouter>
      <Provider store={store}>
        <DropdownElement />
      </Provider>
    </MemoryRouter>
  );

  test("DropdownElement component should render without Errors", () => {
    shallow(wrapper);
  });
  test("DropdownElement component snapshot should match", () => {
    const { asFragment } = render(wrapper);
    expect(asFragment(wrapper)).toMatchSnapshot();
  });
});
