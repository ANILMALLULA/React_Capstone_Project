import React from "react";
import { MemoryRouter } from "react-router-dom";
import { Provider } from "react-redux";
import { cleanup, render } from "@testing-library/react";
import { shallow } from "enzyme";

import store from "../../store";
import TableView from "./TableView";

afterEach(cleanup);
describe("<AllProductsAsTable />", () => {
  const wrapper = (
    <MemoryRouter>
      <Provider store={store}>
        <TableView />
      </Provider>
    </MemoryRouter>
  );

  test("TableView component should render without Errors", () => {
    shallow(wrapper);
  });
  test("TableView component snapshot should match", () => {
    const { asFragment } = render(wrapper);
    expect(asFragment(wrapper)).toMatchSnapshot();
  });
});
