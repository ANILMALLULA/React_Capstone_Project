import * as productActionTypes from "../actions/productsActionTypes";
import userReducer from "./userReducer";

describe("User reducer", () => {
  it("Should return default state", () => {
    const newState = userReducer(userReducer.initialState, {});
    expect(newState).toEqual({
      loginLoading: false,
      registerLoading: false,
      registerSuccess: false,
      loginFailed: false,
      registerFailed: false,
      loginSuccess: localStorage.getItem("loggedIn") === "yes" ? true : false,
      userDetails: localStorage.getItem("userDetails")
        ? JSON.parse(localStorage.getItem("userDetails"))
        : null,
      errors: null,
    });
  });
});
