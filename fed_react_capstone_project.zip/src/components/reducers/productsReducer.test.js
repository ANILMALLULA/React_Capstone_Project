import * as productActionTypes from "../actions/productsActionTypes";
import productsReducer from "./productsReducer";

describe("Products reducer", () => {
  it("Should return default state", () => {
    const newState = productsReducer(productsReducer.initialState, {});
    expect(newState).toEqual({
      addLoading: false,
      addSuccess: false,
      deleteLoading: false,
      deleteSuccess: false,
      errors: null,
      getAllLoading: false,
      products: [],
      productsFields: {
        creationDate: false,
        productDescription: false,
        productManufacturer: true,
        productName: true,
        productPrice: true,
        productQuantity: false,
        views: false,
      },
      searchStatus: false,
      updateLoading: false,
      updateSuccess: false,
    });
  });
});
