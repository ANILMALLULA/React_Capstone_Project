import store from "../../store";
import { MemoryRouter } from "react-router-dom";
import { Provider } from "react-redux";
import { render } from "@testing-library/react";
import { shallow } from "enzyme";

import Registration from "./Registration";

describe("Registration component checking", () => {
  const wrapper = (
    <Provider store={store}>
      <MemoryRouter>
        <Registration />
      </MemoryRouter>
    </Provider>
  );
  it("Register renders without error", () => {
    shallow(wrapper);
    render(wrapper);
  });

  it("Registration heading", () => {
    const { getByText } = render(wrapper);
    expect(getByText("Please Register here")).toBeInTheDocument();
  });

  it("register snapshot should match", () => {
    expect(render(wrapper).asFragment()).toMatchSnapshot();
  });
});
