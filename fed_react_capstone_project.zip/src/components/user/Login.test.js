import Login from "./Login";
import store from "../../store";
import { MemoryRouter } from "react-router-dom";
import { Provider } from "react-redux";
import { cleanup, render } from "@testing-library/react";
import { shallow } from "enzyme";

afterEach(cleanup);

describe("Login test =>", () => {
  const wrapper = (
    <MemoryRouter>
      <Provider store={store}>
        <Login />
      </Provider>
    </MemoryRouter>
  );

  it("Login component renders without error", () => {
    shallow(wrapper);
    render(wrapper);
  });
  it("Login to account is present", () => {
    const { getByText } = render(wrapper);
    expect(getByText("LOGIN PAGE")).toBeInTheDocument();
  });

  it("Dont have account should be present", () => {
    const { getByText } = render(wrapper);
    expect(
      getByText("Dont't have an account? Register here!")
    ).toBeInTheDocument();
  });

  it("login snap shot should match", () => {
    const { asFragment } = render(wrapper);
    expect(asFragment(wrapper)).toMatchSnapshot();
  });
});
