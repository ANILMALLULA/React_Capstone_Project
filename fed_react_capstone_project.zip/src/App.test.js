import { render, screen, cleanup } from "@testing-library/react";
import { shallow } from "enzyme";
import App from "./App";

afterEach(cleanup);

describe("Testing the App component", () => {
  test("renders App heading", () => {
    render(<App />);
    const linkElement = screen.getByText("Product inventory");
    expect(linkElement).toBeInTheDocument();
  });

  it("App rendering or not", () => {
    shallow(<App />);
  });

  it("App rendering as snapshot", () => {
    const wrapper = shallow(<App />);
    expect(wrapper).toMatchSnapshot();
  });
});
